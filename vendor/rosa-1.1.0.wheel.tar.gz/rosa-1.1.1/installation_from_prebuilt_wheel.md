# Rosa

## Installation from prebuilt wheel

```
conda env create -f environment.yml -p ./env
conda activate ./env
pip install -v rosa-*.whl

# Test installation
rosa --help
```



